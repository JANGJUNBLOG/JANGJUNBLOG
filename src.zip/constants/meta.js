export const HOME_TITLE = 'Home'
