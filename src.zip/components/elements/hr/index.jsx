import React from 'react'

import './index.scss'

export const Hr = () => <hr className="custom-hr" />
