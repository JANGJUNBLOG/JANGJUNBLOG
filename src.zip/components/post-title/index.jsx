import React from 'react'

export const PostTitle = ({ title }) => <h1>{title}</h1>
